<section class="mb-4">
    <div class="container">
        <div class="px-2 py-4 p-md-4 shadow-sm" style="background: #4F136D !important; color: #fff;">
            <div class="section-title-1 section-title-1-1 clearfix">
                <h3 class="heading-5 strong-700 mb-0 float-left">
                    <span class="mr-4">{{ translate('Featured Products')}}</span>
                </h3>
            </div>
            <div class="caorusel-box arrow-round gutters-5">
                <div class="slick-carousel" data-slick-items="6" data-slick-xl-items="5" data-slick-lg-items="4"  data-slick-md-items="3" data-slick-sm-items="2" data-slick-xs-items="2" data-slick-autoplay="true">
                    @foreach (filter_products(\App\Product::where('published', 1)->where('featured', '1')->where('current_stock','>',0)->orderBy('featured_sorting', 'asc'))->limit(12)->get() as $key => $product)
                    @if (\App\Seller::where('user_id', $product->user_id)->first()->verification_status == 1)
                    <div class="caorusel-card">
                        <div class="product-card-2 card card-product shop-cards shop-tech">
                            <div class="card-body p-0">


                                   @if(home_price($product->id) != home_discounted_price($product->id))
                                 <div class="notify-badge">{{discountbadge($product->id)}}</div>
                                 @endif
                                <div class="card-image">
                                    <a href="{{ route('product', $product->slug) }}" class="d-block">
                                        <img class="img-fit lazyload mx-auto" src="{{ my_asset('frontend/images/placeholder.jpg') }}" data-src="{{ my_asset($product->thumbnail_img) }}" alt="{{ __($product->name) }}">
                                    </a>
                                </div>
                                <div class="p-md-3 p-2">
                                    <div class="price-box">
                                        @if(home_base_price($product->id) != home_discounted_base_price($product->id))
                                            <del class="old-product-price strong-400">{{ home_base_price($product->id) }}</del>
                                        @endif
                                        <span class="product-price strong-600">{{ home_discounted_base_price($product->id) }}</span>
                                    </div>
                                    <div class="star-rating star-rating-sm mt-1">
                                        {{ renderStarRating($product->rating) }}
                                    </div>
                                    <h2 class="product-title p-0">
                                        <a href="{{ route('product', $product->slug) }}" class="text-truncate">
                                            @if(array_key_exists($product->brand_id, $brands))
                                                {{ $brands[$product->brand_id] }}
                                            @endif
                                        </a>
                                    </h2>
                                    <div class="card-jfy-title"><a href="{{ route('product', $product->slug) }}" style="color:#000">{{ __($product->name) }}</a></div>
                                    @if (\App\Addon::where('unique_identifier', 'club_point')->first() != null && \App\Addon::where('unique_identifier', 'club_point')->first()->activated)
                                        <div class="club-point mt-2 bg-soft-base-1 border-light-base-1 border">
                                            {{ translate('Club Point') }}:
                                            <span class="strong-700 float-right">{{ $product->earn_point }}</span>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                    @endif
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</section>

<style>
    .section-title-1-1:before{

    background:white;
    }
    .section-title-1-1:after{

    background:none;
    }
    </style>
