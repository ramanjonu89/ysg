@if (\App\BusinessSetting::where('type', 'best_selling')->first()->value == 1)
<section class="mb-4">
    <div class="container">
        <div class="px-2 py-4 p-md-4 bg-white shadow-sm">
            <div class="section-title-1 clearfix">
                <h3 class="heading-5 strong-700 mb-0 float-left">
                    <span class="mr-4">{{translate('Best Selling')}}</span>
                </h3>
                <ul class="inline-links float-right">
                    <!--  <li><a  class="active">{{translate('Top 20')}}</a></li> -->
                </ul>
            </div>
            <div class="caorusel-box arrow-round gutters-5">
                <div class="slick-carousel" data-slick-items="3" data-slick-lg-items="2"  data-slick-md-items="2" data-slick-sm-items="1" data-slick-xs-items="1" data-slick-rows="1">
                    @foreach (filter_products(\App\Product::where('published', 1)->where('current_stock','>',0)->orderBy('num_of_sale', 'desc'))->limit(10)->get() as $key => $product)
                    @if (\App\User::where('id', $product->user_id)->first()->company_type == 1)
                    @if (\App\Seller::where('user_id', $product->user_id)->first()->verification_status == 1)
                    <div class="caorusel-card my-1">
                        <div class="row no-gutters product-box-2 align-items-center">
                            <div class="col-5 border-left">
                                <div class="position-relative overflow-hidden h-100">
                                    
                                    @if(home_price($product->id) != home_discounted_price($product->id))
                                 <div class="notify-badge">{{discountbadge($product->id)}}</div>
                                 @endif
                                    
                                    <a href="{{ route('product', $product->slug) }}" class="d-block product-image h-100">
                                        <img class="img-fit lazyload mx-auto" src="{{ my_asset('frontend/images/placeholder.jpg') }}" data-src="{{ my_asset($product->thumbnail_img) }}" alt="{{ __($product->name) }}">
                                    </a>
                                    <div class="product-btns">
                                        <button class="btn add-wishlist" title="Add to Wishlist" onclick="addToWishList({{ $product->id }})">
                                            <i class="la la-heart-o"></i>
                                        </button>
                                        <button class="btn add-compare" title="Add to Compare" onclick="addToCompare({{ $product->id }})">
                                            <i class="la la-refresh"></i>
                                        </button>
                                        <button class="btn quick-view" title="Quick view" onclick="showAddToCartModal({{ $product->id }})">
                                            <i class="la la-eye"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div class="col-7 ">
                                <div class="p-3">
                                    <h2 class="product-title p-0">
                                        <a href="{{ route('product', $product->slug) }}" class="text-truncate">
                                            @if(array_key_exists($product->brand_id, $brands))
                                                {{ $brands[$product->brand_id] }}
                                            @endif
                                        </a>
                                    </h2>
                                     <div class="card-jfy-title"><a href="{{ route('product', $product->slug) }}" style="color:#000">{{ __($product->name) }}</a></div>
                                    <div class="star-rating star-rating-sm mb-2">
                                        {{ renderStarRating($product->rating) }}
                                    </div>
                                    <div class="clearfix">
                                        <div class="price-box float-left">
                                            @if(home_base_price($product->id) != home_discounted_base_price($product->id))
                                            <del class="old-product-price strong-400">{{ home_base_price($product->id) }}</del>
                                            @endif
                                            <span class="product-price strong-600">
                                                {{ home_discounted_base_price($product->id) }}
                                                
                                                
                                            </span>
                                        </div>
                                        <div class="float-right">
                                            <button class="add-to-cart btn" title="Add to Cart" onclick="showAddToCartModal({{ $product->id }})">
                                                <i class="la la-shopping-cart"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endif
                    @endif
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</section>
@endif
