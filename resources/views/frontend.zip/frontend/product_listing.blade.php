@extends('frontend.layouts.app')
@if(isset($subsubcategory_id))
    @php
        $meta_title = \App\SubSubCategory::find($subsubcategory_id)->meta_title;
        $meta_description = \App\SubSubCategory::find($subsubcategory_id)->meta_description;
    @endphp
@elseif (isset($subcategory_id))
    @php
        $meta_title = \App\SubCategory::find($subcategory_id)->meta_title;
        $meta_description = \App\SubCategory::find($subcategory_id)->meta_description;
    @endphp
@elseif (isset($category_id))
    @php
        $meta_title = \App\Category::find($category_id)->meta_title;
        $meta_description = \App\Category::find($category_id)->meta_description;
    @endphp
@elseif (isset($brand_id))
    @php
        $meta_title = \App\Brand::find($brand_id)->meta_title;
        $meta_description = \App\Brand::find($brand_id)->meta_description;
    @endphp
@else
    @php
        $meta_title = env('APP_NAME');
        $meta_description = \App\SeoSetting::first()->description;
    @endphp
@endif
@section('meta_title'){{ $meta_title }}@stop
@section('meta_description'){{ $meta_description }}@stop
@section('meta')
    <!-- Schema.org markup for Google+ -->
    <meta itemprop="name" content="{{ $meta_title }}">
    <meta itemprop="description" content="{{ $meta_description }}">
    <!-- Twitter Card data -->
    <meta name="twitter:title" content="{{ $meta_title }}">
    <meta name="twitter:description" content="{{ $meta_description }}">
    <!-- Open Graph data -->
    <meta property="og:title" content="{{ $meta_title }}"/>
    <meta property="og:description" content="{{ $meta_description }}"/>
@endsection
@section('content')
    <div class="breadcrumb-area">
        <div class="container">
            <div class="row">
                <div class="col">
                    <ul class="breadcrumb">
                        <li><a href="{{ route('home') }}">{{ translate('Home')}}</a></li>
                        <li><a href="{{ route('products') }}">{{ translate('All Categories')}}</a></li>
                        @if(isset($category_id))
                            <li class="active"><a
                                    href="{{ route('products.category', \App\Category::find($category_id)->slug) }}">{{ \App\Category::find($category_id)->name }}</a>
                            </li>
                        @endif
                        @if(isset($subcategory_id))
                            <li>
                                <a href="{{ route('products.category', \App\SubCategory::find($subcategory_id)->category->slug) }}">{{ \App\SubCategory::find($subcategory_id)->category->name }}</a>
                            </li>
                            <li class="active"><a
                                    href="{{ route('products.subcategory', \App\SubCategory::find($subcategory_id)->slug) }}">{{ \App\SubCategory::find($subcategory_id)->name }}</a>
                            </li>
                        @endif
                        @if(isset($subsubcategory_id))
                            <li>
                                <a href="{{ route('products.category', \App\SubSubCategory::find($subsubcategory_id)->subcategory->category->slug) }}">{{ \App\SubSubCategory::find($subsubcategory_id)->subcategory->category->name }}</a>
                            </li>
                            <li>
                                <a href="{{ route('products.subcategory', \App\SubsubCategory::find($subsubcategory_id)->subcategory->slug) }}">{{ \App\SubsubCategory::find($subsubcategory_id)->subcategory->name }}</a>
                            </li>
                            <li class="active"><a
                                    href="{{ route('products.subsubcategory', \App\SubSubCategory::find($subsubcategory_id)->slug) }}">{{ \App\SubSubCategory::find($subsubcategory_id)->name }}</a>
                            </li>
                        @endif
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <section class="gry-bg py-4">
        <div class="container sm-px-0">
            <form class="" id="search-form" action="{{ route('search') }}" method="GET">
                <div class="row">
                    <div class="col-xl-3 side-filter d-xl-block">
                        <div class="filter-overlay filter-close"></div>
                        <div class="filter-wrapper c-scrollbar">
                            <div class="filter-title d-flex d-xl-none justify-content-between pb-3 align-items-center">
                                <h3 class="h6">Filters</h3>
                                <button type="button" class="close filter-close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="bg-white sidebar-box mb-3">
                                <!-- Category Filter -->
                                <div class="box-title bg-white border-bottom-0 border-top">
                                    <h6 class="font-weight-bold mb-0">{{ translate('Categories')}}</h6>
                                </div>
                                <div class="box-content pr-3 pl-3 pb-3">
                                    @foreach ($categories as $key => $category)
                                        <div class="category-title {{ $key >= 5 ? 'category-hidden-item' : '' }} pb-2" style="{{ $key >= 5 ? 'display:none' : '' }}">
                                            <a class="alert-link text-dark" href="{{ route('products.category', $category->slug) }}">
                                                {{ __($category->name) }}
                                            </a>
                                            @if(count($category->subcategories) > 0)
                                            <a class="dropdown-toggle text-dark" data-toggle="collapse" href="#category-collapse-{{ $category->id }}" role="button" aria-expanded="false" aria-controls="category-collapse-{{ $category->id }}"></a>
                                            @endif
                                        </div>
                                        <div class="collapse pr-3 pl-3" id="category-collapse-{{ $category->id }}">
                                            @foreach($category->subcategories as $subCategory)
                                                @if ($subCategory->status == 1)
                                                    <div class="pb-2">
                                                        <a class="alert-link text-muted" href="{{ route('products.subcategory', $subCategory->slug) }}">
                                                            {{ __($subCategory->name) }}
                                                        </a>
                                                        @if(count($subCategory->subsubcategories) > 0)
                                                            <a class="dropdown-toggle text-muted" data-toggle="collapse" href="#subcategory-collapse-{{ $subCategory->id }}" role="button"></a>
                                                        @endif
                                                    </div>
                                                    @if(count($subCategory->subsubcategories) > 0)
                                                        <div class="collapse pr-3 pl-3" id="subcategory-collapse-{{ $subCategory->id }}">
                                                            @foreach($subCategory->subsubcategories as $subSubCategory)
                                                                @if ($subSubCategory->status == 1)
                                                                    <div class="pb-2">
                                                                        <a class="alert-link text-black-50" href="{{ route('products.subsubcategory', $subSubCategory->slug) }}">
                                                                            {{ __($subSubCategory->name) }}
                                                                        </a>
                                                                    </div>
                                                                @endif
                                                            @endforeach
                                                        </div>
                                                    @endif
                                                @endif
                                            @endforeach
                                        </div>
                                    @endforeach
                                    @if(count($categories) >= 6)
                                        <div class="text-center text-black-50">
                                            <span role="button" data-status="hide" id="view-more-categories">
                                                <span>{{ __('View more') }}</span>
                                                <i class="caret-icon fa fa-caret-down"></i>
                                            </span>
                                        </div>
                                    @endif
                                </div>
                                <!-- END -->

                                <!-- Brand Filter -->
                                <div class="box-title bg-white border-bottom-0 border-top">
                                    <h6 class="font-weight-bold mb-0">{{ translate('Brands')}}</h6>
                                </div>
                                <div class="box-content pr-3 pl-3 pb-3">
                                    <!-- Filter by color -->
                                    @foreach($brands as $key => $brand)
                                        <div class="custom-control custom-checkbox {{ $key >= 5 ? 'brand-hidden-item' : '' }}" style="{{ $key >= 5 ? 'display:none' : '' }}">
                                            <input name="brand_ids[]" type="checkbox" class="custom-control-input"
                                                   id="custom-cb-brand-{{ $brand->id }}" value="{{ $brand->id }}"
                                                   @isset($brand_ids) @if (in_array($brand->id, $brand_ids)) checked @endif @endisset
                                                   onchange="filter()"
                                            >
                                            <label class="custom-control-label" for="custom-cb-brand-{{ $brand->id }}">{{ $brand->name }}</label>
                                        </div>
                                    @endforeach
                                    @if(count($brands) >= 6)
                                        <div class="text-center text-black-50">
                                            <span role="button" data-status="hide" id="view-more-brands">
                                                <span>{{ __('View more') }}</span>
                                                <i class="caret-icon fa fa-caret-down"></i>
                                            </span>
                                        </div>
                                    @endif
                                </div>
                                <!-- END -->

                                <!-- Seller Filter -->
                                <div class="box-title bg-white border-bottom-0 border-top">
                                    <h6 class="font-weight-bold mb-0">{{ translate('Sellers')}}</h6>
                                </div>
                                <div class="box-content pr-3 pl-3 pb-3">
                                    @foreach($sellers as $key => $seller)
                                        <div class="custom-control custom-checkbox {{ $key >= 5 ? 'seller-hidden-item' : '' }}" style="{{ $key >= 5 ? 'display:none' : '' }}">
                                            <input name="seller_ids[]" type="checkbox" class="custom-control-input"
                                                   id="custom-cb-seller-{{ $seller->id }}" value="{{ $seller->id }}"
                                                   @isset($seller_ids) @if (in_array($seller->id, $seller_ids)) checked @endif @endisset
                                                   onchange="filter()"
                                            >
                                            <label class="custom-control-label" for="custom-cb-seller-{{ $seller->id }}">{{ $seller->name }}</label>
                                        </div>
                                    @endforeach
                                        @if(count($sellers) >= 6)
                                            <div class="text-center text-black-50">
                                            <span role="button" data-status="hide" id="view-more-sellers">
                                                <span>{{ __('View more') }}</span>
                                                <i class="caret-icon fa fa-caret-down"></i>
                                            </span>
                                            </div>
                                        @endif
                                </div>
                                <!-- END -->

                                <!-- Price Filter -->
                                <div class="box-title bg-white border-bottom-0 border-top">
                                    <h6 class="font-weight-bold mb-0">{{ translate('Price range')}}</h6>
                                </div>
                                <div class="box-content pr-3 pl-3 pb-3">
                                    <div class="form-row d-flex align-items-center justify-content-between">
                                        <input name="min_price" value="{{ $min_price }}" type="number" placeholder="Min" class="form-control col-md-5">
                                        <div class="col-md-1 border-bottom border-dark"></div>
                                        <input name="max_price" value="{{ $max_price }}"  type="number" placeholder="Max" class="form-control col-md-5">
                                    </div>
                                </div>
                                <!-- END -->

                                <!-- Color Filter -->
                                @if(count($all_colors) > 0)
                                    <div class="box-title bg-white border-bottom-0 border-top">
                                        <h6 class="font-weight-bold mb-0">{{ translate('Filter by color')}}</h6>
                                    </div>
                                    <div class="box-content pr-3 pl-3 pb-3">
                                        <!-- Filter by color -->
                                        <ul class="list-inline checkbox-color checkbox-color-circle mb-0">
                                            @foreach ($all_colors as $key => $color)
                                                <li>
                                                    <input type="radio" id="color-{{ $key }}" name="color"
                                                           value="{{ $color }}"
                                                           @if(isset($selected_color) && $selected_color == $color) checked
                                                           @endif onchange="filter()">
                                                    <label style="background: {{ $color }};" for="color-{{ $key }}"
                                                           data-toggle="tooltip"
                                                           data-original-title="{{ \App\Color::where('code', $color)->first()->name }}"></label>
                                                </li>
                                            @endforeach
                                        </ul>
                                    </div>
                                @endif
                                @foreach ($attributes as $key => $attribute)
                                    @if (array_key_exists($attribute['id'], $existing_attributes))
                                        <div class="box-title bg-white border-bottom-0 border-top">
                                            <h6 class="font-weight-bold mb-0">
                                                Filter by {{ $existing_attributes[$attribute['id']] }}
                                            </h6>
                                        </div>
                                        <div class="box-content pr-3 pl-3 pb-3">
                                            <!-- Filter by others -->
                                            @foreach ($attribute['values'] as $key => $value)
                                                @php
                                                    $flag = false;
                                                    if (array_key_exists($attribute['id'], $selected_attributes)) {
                                                        if (in_array($value, $selected_attributes[$attribute['id']])) {
                                                            $flag = true;
                                                        }
                                                    }

                                                @endphp
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input"
                                                           id="attribute_{{ $attribute['id'] }}_value_{{ $value }}"
                                                           name="attribute_{{ $attribute['id'] }}[]"
                                                           value="{{ $value }}" @if ($flag) checked
                                                           @endif onchange="filter()">
                                                    <label class="custom-control-label"
                                                           for="attribute_{{ $attribute['id'] }}_value_{{ $value }}">{{ $value }}</label>
                                                </div>
                                            @endforeach
                                        </div>
                                @endif
                            @endforeach
                                <!-- END -->
                            </div>

                            {{-- <button type="submit" class="btn btn-styled btn-block btn-base-4">Apply filter</button> --}}
                        </div>
                    </div>
                    <div class="col-xl-9">
                        <!-- <div class="bg-white"> -->
                        @isset($category_id)
                            <input type="hidden" name="category" value="{{ \App\Category::find($category_id)->slug }}">
                        @endisset
                        @isset($subcategory_id)
                            <input type="hidden" name="subcategory"
                                   value="{{ \App\SubCategory::find($subcategory_id)->slug }}">
                        @endisset
                        @isset($subsubcategory_id)
                            <input type="hidden" name="subsubcategory"
                                   value="{{ \App\SubSubCategory::find($subsubcategory_id)->slug }}">
                        @endisset
                        <div class="sort-by-bar row no-gutters bg-white mb-3 px-3 pt-2">
                            <div class="col-xl-7 d-flex d-xl-block justify-content-between align-items-end ">
                                <div class="sort-by-box flex-grow-1">
                                    <div class="form-group">
                                        <label>{{ translate('Search')}}</label>
                                        <div class="search-widget">
                                            <input class="form-control input-lg" type="text" name="q"
                                                   placeholder="{{ translate('Search products')}}"
                                                   @isset($query) value="{{ $query }}" @endisset>
                                            <button type="submit" class="btn-inner">
                                                <i class="fa fa-search"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="d-xl-none ml-3 form-group">
                                    <button type="button" class="btn p-1 btn-sm" id="side-filter">
                                        <i class="la la-filter la-2x"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="col-xl-4 offset-xl-1">
                                <div class="row no-gutters">
                                    <div class="col-12">
                                        <div class="sort-by-box px-1">
                                            <div class="form-group">
                                                <label>{{ translate('Sort by')}}</label>
                                                <select class="form-control sortSelect"
                                                        data-minimum-results-for-search="Infinity" name="sort_by"
                                                        onchange="filter()">
                                                    <option value="1"
                                                            @isset($sort_by) @if ($sort_by == '1') selected @endif @endisset>{{ translate('Newest')}}</option>
                                                    <option value="2"
                                                            @isset($sort_by) @if ($sort_by == '2') selected @endif @endisset>{{ translate('Oldest')}}</option>
                                                    <option value="3"
                                                            @isset($sort_by) @if ($sort_by == '3') selected @endif @endisset>{{ translate('Price low to high')}}</option>
                                                    <option value="4"
                                                            @isset($sort_by) @if ($sort_by == '4') selected @endif @endisset>{{ translate('Price high to low')}}</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- <hr class=""> -->
                        <div class="products-box-bar p-3 bg-white">
                            <div class="row sm-no-gutters gutters-5">
                                @foreach ($products as $key => $product)
                                    <div class="col-xxl-3 col-xl-4 col-lg-3 col-md-4 col-6">
                                        <div class="product-box-2 bg-white alt-box my-md-2">
                                            <div class="position-relative overflow-hidden">

                                                <a href="{{ route('product', $product->slug) }}"
                                                   class="d-block product-image text-center" tabindex="0">
                                                    @if   ($product->discount > 0)
                                                        <div
                                                            class="notify-badge">{{discountbadge($product->id)}}</div>
                                                    @endif
                                                    <img class="img-fit lazyload"
                                                         src="{{ my_asset('frontend/images/placeholder.jpg') }}"
                                                         data-src="{{ my_asset($product->thumbnail_img) }}"
                                                         alt="{{  __($product->name) }}">
                                                </a>
                                                <div class="product-btns clearfix">
                                                    <button class="btn add-wishlist" title="Add to Wishlist"
                                                            onclick="addToWishList({{ $product->id }})"
                                                            type="button">
                                                        <i class="la la-heart-o"></i>
                                                    </button>
                                                    <button class="btn add-compare" title="Add to Compare"
                                                            onclick="addToCompare({{ $product->id }})"
                                                            type="button">
                                                        <i class="la la-refresh"></i>
                                                    </button>
                                                    <button class="btn quick-view" title="Quick view"
                                                            onclick="showAddToCartModal({{ $product->id }})"
                                                            type="button">
                                                        <i class="la la-eye"></i>
                                                    </button>
                                                </div>
                                            </div>
                                            <div class="p-md-3 p-2">
                                                <div class="price-box">
                                                    @if(home_base_price($product->id) != home_discounted_base_price($product->id))
                                                        <del
                                                            class="old-product-price strong-400">{{ home_base_price($product->id) }}</del>
                                                    @endif
                                                    <span
                                                        class="product-price strong-600">{{ home_discounted_base_price($product->id) }}</span>
                                                </div>
                                                <div class="star-rating star-rating-sm mt-1">
                                                    {{ renderStarRating($product->rating) }}
                                                </div>
                                                <h2 class="product-title p-0">
                                                    <a href="{{ route('product', $product->slug) }}"
                                                       class="text-truncate">
                                                        @foreach($brands as $brand)
                                                            @if($brand->id == $product->brand_id)
                                                                {{ $brand->name }}
                                                                @break
                                                            @endif
                                                        @endforeach
                                                    </a>
                                                </h2>
                                                <div class="card-jfy-title"><a
                                                        href="{{ route('product', $product->slug) }}"
                                                        style="color:#000">{{ __($product->name) }}</a></div>
                                                @if (\App\Addon::where('unique_identifier', 'club_point')->first() != null && \App\Addon::where('unique_identifier', 'club_point')->first()->activated)
                                                    <div
                                                        class="club-point mt-2 bg-soft-base-1 border-light-base-1 border">
                                                        {{  translate('Club Point') }}:
                                                        <span
                                                            class="strong-700 float-right">{{ $product->earn_point }}</span>
                                                    </div>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                @endforeach

                            </div>
                        </div>
                        <div class="products-pagination bg-white p-3">
                            <nav aria-label="Center aligned pagination">
                                <ul class="pagination justify-content-center">
                                    {{ $products->links() }}
                                </ul>
                            </nav>
                        </div>
                        <!-- </div> -->
                    </div>
                </div>
            </form>
        </div>
    </section>
@endsection
@section('script')
    <script src="{{ static_asset('/js/view_more.js')}}"></script>
    <script type="text/javascript">
        function filter() {
            $('#search-form').submit();
        }
    </script>
@endsection
<style>
    .category-sidebar1 ul.categories {
        position: relative !important;
        height: 300px !important;
        overflow: scroll;
        box-shadow: none !important;
    }

    .category-sidebar1 ul.categories:hover {
        width: 900px;
    }

    .category-sidebar1 {
        background-color: #fff;
    }

    .category-sidebar1 .all-category {
        height: 49px;
        line-height: 49px;
        padding-left: 16px;
        font-size: 16px;
        color: #fff;
        background-color: rgba(88, 55, 134, 1);
    }

    .category-sidebar1 .all-category > span {
        font-size: 16px;
        margin-right: 130px;
        font-weight: 600;
        color: #fff;
    }

    .category-sidebar1 .all-category a {
        color: #fff;
        font-size: 12px;
    }

    .category-sidebar1 .categories > li {
        border: 0;
    }

    .category-sidebar1 .categories > li > a {
        padding: 8px 10px;
        color: #333;
        font-size: 16px;
        border: 1px solid transparent;
        position: relative;
    }

    .category-sidebar1 .categories > li:hover > a::before {
        position: absolute;
        height: 100%;
        width: 3px;
        background: #fff;
        content: "";
        top: 0;
        right: -2px;
        z-index: 999;
        display: block;
    }

    .category-sidebar1 .categories > li:hover > a {
        border-color: #fff;
    }

    .category-sidebar1 .all-category a:hover {
        color: #fff !important;
    }

    .category-sidebar1 .categories > li > a .cat-image {
        width: 16px;
        opacity: 0.6;
        margin-right: 10px;
    }

    .category-sidebar1 .sub-cat-menu {
        display: none;
        /* width: 800px !important; */
        position: absolute;
        /* margin: auto; */
        left: 100px;
        height: 500px;
        /* overflow: hidden; */
        top: 0px;
        z-index: 100;
        background-color: #fff;
        border: 1px solid #eee;
        overflow-y: auto;
        box-shadow: 0 3px 3px 0 rgba(51, 51, 51, 0.2);
    }

    .category-sidebar1 .categories > li:hover .sub-cat-menu {
        display: block;
    }

    .sub-cat-content .sub-cat-list {
        padding: 10px;
        padding-top: 0;
    }

    .sub-cat-content .sub-cat-list .card {
        margin: 10px;
        border: 0;
    }

    .card .sub-cat-items {
        padding: 0;
        list-style: none;
    }

    .card .sub-cat-items li a {
        font-size: 16px;
        color: #333;
        display: block;
        text-overflow: ellipsis;
        word-wrap: normal;
        white-space: nowrap;
        overflow: hidden;
        line-height: 26px;
    }

    .card .sub-cat-items li.sub-cat-name a {
        margin-bottom: 5px;
        font-weight: 600;
        line-height: 35px;
        height: 35px;
        border-bottom: 1px solid #e9e9e9;
    }

    .sub-cat-featured {
        padding: 20px;
    }

    .sub-cat-featured a {
        display: flex;
        height: 60px;
        border: 1px solid #e9e9e9;
        text-align: right;
    }

    .sub-cat-featured a .featured-img {
        height: auto;
        width: 70px;
        background: #fff;
        margin-top: -10px;
        margin-right: 6px;
    }

    .sub-cat-featured a .featured-name {
        width: 100%;
        padding: 13px 20px 13px 13px;
        font-size: 16px;
        font-weight: 600;
        line-height: 16px;
        height: 42px;
        overflow: hidden;
        white-space: normal;
        word-wrap: break-word;
        text-align: left;
    }

    .sub-cat-brand {
        padding: 10px 15px;
        padding-left: 25px;
    }

    .sub-cat-brand .sub-brand-list {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap;
        padding: 0;
        list-style: none;
    }

    .sub-cat-brand .sub-brand-item {
        width: calc(50% - 4px);
        height: 50px;
        border: 1px solid #e9e9e9;
        padding: 5px 10px;
        margin: 2px;
        overflow: hidden;
        background-color: #fff;
    }

    .sub-cat-brand .sub-brand-item img {
        max-width: 80px;
        max-height: 40px;
    }

    /* icon hover category menu */
    .hover-category-menu {
        position: absolute;
        width: 100%;
        display: none;
    }

    .hover-category-menu .category-sidebar1 {
        box-shadow: 0 3px 3px 0 rgba(51, 51, 51, 0.2);
        padding-top: 22px;
    }

    .hover-category-menu .category-sidebar1 .all-category {
        position: relative;
    }

    .hover-category-menu .category-sidebar1 .all-category::before {
        position: absolute;
        height: 8px;
        width: 8px;
        border-top: 0;
        border-right: 8px solid transparent;
        border-bottom: 8px solid #f2f2f2;
        border-left: 8px solid transparent;
        right: 20px;
    }

    .hover-category-menu .all-category {
        padding-left: 10px;
        line-height: 41px;
        height: 49px;
        line-height: 49px;
        color: #333;
        border-bottom: 1px solid #e9e9e9;
    }

    .hover-category-menu .all-category span {
        font-size: 14px;
    }

    .hover-category-menu .category-sidebar1 .sub-cat-menu {
        height: calc(100% - 8px);
        top: 8px;
        box-shadow: 2px 3px 5px 0 rgba(51, 51, 51, 0.2);
    }

    .hover-category-menu .category-sidebar1 .categories > li > a {
        padding: 8px 10px;
    }

    .notify-badge {
        position: absolute;
        right: 10px !important;
    }
</style>
