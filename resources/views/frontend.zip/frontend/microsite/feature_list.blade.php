<div class="container">
    <div class="px-2 py-4 p-md-4 shadow-sm" style="background: #4F136D !important; color: #fff;">
        <div class="section-title-1 section-title-1-1 clearfix">
            <h3 class="heading-5 strong-700 mb-0 float-left">
                <span class="mr-4">Featured Products</span>
            </h3>
        </div>
        <div class="caorusel-box arrow-round gutters-5">
            <div class="slick-carousel slick-initialized slick-slider" data-slick-items="6"
                 data-slick-xl-items="5" data-slick-lg-items="4" data-slick-md-items="3" data-slick-sm-items="2"
                 data-slick-xs-items="2" data-slick-autoplay="true">
                <div class="slick-list draggable">
                    <div class="slick-track"
                         style="opacity: 1; width: 892px; transform: translate3d(0px, 0px, 0px);">
                        <div class="caorusel-card slick-slide slick-current slick-active" style="width: 223px;"
                             tabindex="0" data-slick-index="0" aria-hidden="false">
                            <div class="product-card-2 card card-product shop-cards shop-tech">
                                <div class="card-body p-0">
                                    <div class="card-image">
                                        <a href="http://ysg.vm/product/long-wear-daily-sunscreen-spf40-pa--tsf005"
                                           class="d-block" tabindex="0">
                                            <img class="img-fit mx-auto ls-is-cached lazyloaded"
                                                 src="http://ysg.vm/uploads/products/photos/TSF005-.1.jpg"
                                                 data-src="http://ysg.vm/uploads/products/photos/TSF005-.1.jpg"
                                                 alt="Long Wear Daily Sunscreen SPF40 PA+++">
                                        </a>
                                    </div>
                                    <div class="p-md-3 p-2">
                                        <div class="price-box">
                                            <span class="product-price strong-600">$15.90</span>
                                        </div>
                                        <div class="star-rating star-rating-sm mt-1">
                                            <i class="fa fa-star"></i><i class="fa fa-star"></i><i
                                                class="fa fa-star"></i><i class="fa fa-star"></i><i
                                                class="fa fa-star"></i>
                                        </div>
                                        <h2 class="product-title p-0">
                                            <a href="http://ysg.vm/product/long-wear-daily-sunscreen-spf40-pa--tsf005"
                                               class="text-truncate" tabindex="0">
                                                The Skin Firm
                                            </a>
                                        </h2>
                                        <div class="card-jfy-title">
                                            <a href="http://ysg.vm/product/long-wear-daily-sunscreen-spf40-pa--tsf005"
                                               style="color:#000" tabindex="0">Long Wear Daily Sunscreen SPF40
                                                PA+++</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="caorusel-card slick-slide slick-active" style="width: 223px;" tabindex="0"
                             data-slick-index="1" aria-hidden="false">
                            <div class="product-card-2 card card-product shop-cards shop-tech">
                                <div class="card-body p-0">
                                    <div class="card-image">
                                        <a href="http://ysg.vm/product/natural-micellar-water-tsf001"
                                           class="d-block" tabindex="0">
                                            <img class="img-fit mx-auto ls-is-cached lazyloaded"
                                                 src="http://ysg.vm/uploads/products/photos/TSF001-.1.jpg"
                                                 data-src="http://ysg.vm/uploads/products/photos/TSF001-.1.jpg"
                                                 alt="Natural Micellar Water">
                                        </a>
                                    </div>
                                    <div class="p-md-3 p-2">
                                        <div class="price-box">
                                            <span class="product-price strong-600">$22.90</span>
                                        </div>
                                        <div class="star-rating star-rating-sm mt-1">
                                            <i class="fa fa-star"></i><i class="fa fa-star"></i><i
                                                class="fa fa-star"></i><i class="fa fa-star"></i><i
                                                class="fa fa-star"></i>
                                        </div>
                                        <h2 class="product-title p-0">
                                            <a href="http://ysg.vm/product/natural-micellar-water-tsf001"
                                               class="text-truncate" tabindex="0">
                                                The Skin Firm
                                            </a>
                                        </h2>
                                        <div class="card-jfy-title"><a
                                                href="http://ysg.vm/product/natural-micellar-water-tsf001"
                                                style="color:#000" tabindex="0">Natural Micellar Water</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="caorusel-card slick-slide slick-active" style="width: 223px;" tabindex="0"
                             data-slick-index="2" aria-hidden="false">
                            <div class="product-card-2 card card-product shop-cards shop-tech">
                                <div class="card-body p-0">
                                    <div class="card-image">
                                        <a href="http://ysg.vm/product/timeless-youth-elixir-tsf004"
                                           class="d-block" tabindex="0">
                                            <img class="img-fit mx-auto ls-is-cached lazyloaded"
                                                 src="http://ysg.vm/uploads/products/photos/TSF004-.1.jpg"
                                                 data-src="http://ysg.vm/uploads/products/photos/TSF004-.1.jpg"
                                                 alt="Timeless Youth Elixir">
                                        </a>
                                    </div>
                                    <div class="p-md-3 p-2">
                                        <div class="price-box">
                                            <span class="product-price strong-600">$33.90</span>
                                        </div>
                                        <div class="star-rating star-rating-sm mt-1">
                                            <i class="fa fa-star"></i><i class="fa fa-star"></i><i
                                                class="fa fa-star"></i><i class="fa fa-star"></i><i
                                                class="fa fa-star"></i>
                                        </div>
                                        <h2 class="product-title p-0">
                                            <a href="http://ysg.vm/product/timeless-youth-elixir-tsf004"
                                               class="text-truncate" tabindex="0">
                                                The Skin Firm
                                            </a>
                                        </h2>
                                        <div class="card-jfy-title"><a
                                                href="http://ysg.vm/product/timeless-youth-elixir-tsf004"
                                                style="color:#000" tabindex="0">Timeless Youth Elixir</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="caorusel-card slick-slide slick-active" style="width: 223px;" tabindex="0"
                             data-slick-index="3" aria-hidden="false">
                            <div class="product-card-2 card card-product shop-cards shop-tech">
                                <div class="card-body p-0">
                                    <div class="card-image">
                                        <a href="http://ysg.vm/product/youth-therapy-essence-tsf003"
                                           class="d-block" tabindex="0">
                                            <img class="img-fit mx-auto ls-is-cached lazyloaded"
                                                 src="http://ysg.vm/uploads/products/photos/TSF003-.1.jpg"
                                                 data-src="http://ysg.vm/uploads/products/photos/TSF003-.1.jpg"
                                                 alt="Youth Therapy Essence">
                                        </a>
                                    </div>
                                    <div class="p-md-3 p-2">
                                        <div class="price-box">
                                            <span class="product-price strong-600">$29.90</span>
                                        </div>
                                        <div class="star-rating star-rating-sm mt-1">
                                            <i class="fa fa-star"></i><i class="fa fa-star"></i><i
                                                class="fa fa-star"></i><i class="fa fa-star"></i><i
                                                class="fa fa-star"></i>
                                        </div>
                                        <h2 class="product-title p-0">
                                            <a href="http://ysg.vm/product/youth-therapy-essence-tsf003"
                                               class="text-truncate" tabindex="0">
                                                The Skin Firm
                                            </a>
                                        </h2>
                                        <div class="card-jfy-title"><a
                                                href="http://ysg.vm/product/youth-therapy-essence-tsf003"
                                                style="color:#000" tabindex="0">Youth Therapy Essence</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
