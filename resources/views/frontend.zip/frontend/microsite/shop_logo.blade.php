<div class="container">
    <div class="row align-items-baseline">
        <div class="col-md-6">
            <div class="d-flex">
                <img height="70" class=" lazyloaded"
                     src=" http://ysg.vm/uploads/shop/logo/kxo2HFfuSkIprGuiLmZNMnUeVnPimx8GIFjZzS0v.png "
                     data-src=" http://ysg.vm/uploads/shop/logo/kxo2HFfuSkIprGuiLmZNMnUeVnPimx8GIFjZzS0v.png "
                     alt="The Skin Firm">
                <div class="pl-4">
                    <h3 class="strong-700 heading-4 mb-0">The Skin Firm <span class="ml-2"><i
                                class="fa fa-check-circle" style="color:green"></i></span>
                    </h3>
                    <div class="star-rating star-rating-sm mb-1">
                        <i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i
                            class="fa fa-star"></i><i class="fa fa-star"></i>
                    </div>
                    <div class="location alpha-6"></div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <ul class="text-md-right mt-4 mt-md-0 social-nav model-2">
                <li>
                    <a href="http://facebook.com/skinfirm.co" class="facebook social_a" target="_blank"
                       data-toggle="tooltip" data-original-title="Facebook">
                        <i class="fa fa-facebook" style="margin-top: 10px;"></i>
                    </a>
                </li>
                <li>
                    <a href="http://instagram.com/therealskinfirm" class="instagram social_a" target="_blank"
                       data-toggle="tooltip" data-original-title="instagram">
                        <i class="fa fa-instagram" style="margin-top: 10px;"></i>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>
