<div class="container">
    <form>
        <div class="row align-items-baseline">
            <div class="col">
                <span>{{ translate('New Arrival Products')}}</span>
            </div>
        </div>
        <div class="row align-items-baseline">
            <div class="col-4 d-flex justify-content-between align-items-end ">
                <div class="sort-by-box flex-grow-1">
                    <div class="form-group">
                        <label>Search</label>
                        <div class="search-widget">
                            <input class="form-control input-lg" type="text" name="q" placeholder="Search products">
                            <button type="submit" class="btn-inner">
                                <i class="fa fa-search"></i>
                            </button>
                        </div>
                    </div>
                </div>
                <div class="d-xl-none ml-3 form-group">
                    <button type="button" class="btn p-1 btn-sm" id="side-filter">
                        <i class="la la-filter la-2x"></i>
                    </button>
                </div>
            </div>

            <div class="col-2">
                <div class="row no-gutters">
                    <div class="col-12">
                        <div class="sort-by-box px-1">
                            <div class="form-group">
                                <label>{{ translate('Filter by category')}}</label>
                                <select class="form-control sortSelect"
                                        data-minimum-results-for-search="Infinity" name="sort_by"
                                        onchange="filter()">
                                    <option value="">{{ translate('All Categories')}}</option>
                                    <option value="1">{{ translate('Cate 1')}}</option>
                                    <option value="2">{{ translate('Cate 2')}}</option>
                                    <option value="3">{{ translate('Cate 3')}}</option>
                                    <option value="4">{{ translate('Cate 4')}}</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-2">
                <div class="row no-gutters">
                    <div class="col-12">
                        <div class="sort-by-box px-1">
                            <div class="form-group">
                                <label>{{ translate('Filter by brands')}}</label>
                                <select class="form-control sortSelect"
                                        data-minimum-results-for-search="Infinity" name="sort_by"
                                        onchange="filter()">
                                    <option value="">{{ translate('All Brands')}}</option>
                                    <option value="1">{{ translate('Brand 1')}}</option>
                                    <option value="2">{{ translate('Brand 2')}}</option>
                                    <option value="3">{{ translate('Brand 3')}}</option>
                                    <option value="4">{{ translate('Brand 4')}}</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-2">
                <div class="row no-gutters">
                    <div class="col-12">
                        <div class="sort-by-box px-1">
                            <div class="form-group">
                                <label>{{ translate('Sort by')}}</label>
                                <select class="form-control sortSelect"
                                        data-minimum-results-for-search="Infinity" name="sort_by"
                                        onchange="filter()">
                                    <option value="1">{{ translate('Newest')}}</option>
                                    <option value="2">{{ translate('Oldest')}}</option>
                                    <option value="3">{{ translate('Price low to high')}}</option>
                                    <option value="4">{{ translate('Price high to low')}}</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-2">
                <div class="row no-gutters">
                    <div class="col-12">
                        <div class="sort-by-box px-1">
                            <div class="form-group">
                                <label>{{ translate('Display')}}</label>
                                <select class="form-control sortSelect"
                                        data-minimum-results-for-search="Infinity" name="sort_by"
                                        onchange="filter()">
                                    <option value="20">{{ translate('20')}}</option>
                                    <option value="30">{{ translate('30')}}</option>
                                    <option value="40">{{ translate('40')}}</option>
                                    <option value="50">{{ translate('50')}}</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
