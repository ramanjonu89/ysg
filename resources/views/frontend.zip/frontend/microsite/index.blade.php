@extends('frontend.layouts.microsite')
@section('content')
    <section class="gry-bg pt-4 ">
        @component('frontend/microsite/shop_logo')
            <strong>Whoops!</strong> banner
        @endcomponent
    </section>
    <pre id="popupTitle" class="d-none"></pre>
    <section class="bg-white">
        <div class="container">
            <div class="row sticky-top mt-4">
                <div class="col">
                    <div class="seller-shop-menu">
                        <ul class="inline-links">
                            <li class="active"><a href="http://ysg.vm/shops/visit/The-Skin-Firm-13">Store Home</a></li>

                            <li><a href="http://ysg.vm/shops/visit/The-Skin-Firm-13/all_products">All Products</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="py-4">
        @component('frontend/microsite/banner')
            <strong>Whoops!</strong> banner
        @endcomponent
    </section>
    <section class="mb-4">
        @component('frontend/microsite/feature_list')
            <strong>Whoops!</strong> feature_list
        @endcomponent
    </section>

    <section class="mb-4">
        @component('frontend/microsite/search_bar')
            <strong>Whoops!</strong> feature_list
        @endcomponent
    </section>
    <section class="mb-4">
        @component('frontend/microsite/product_list')
            <strong>Whoops!</strong> feature_list
        @endcomponent
    </section>
@endsection
