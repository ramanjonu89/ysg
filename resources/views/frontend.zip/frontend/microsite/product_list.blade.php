<div class="container">
    <div class="row sm-no-gutters gutters-5">
        <div class="col-xxl-2 col-xl-2 col-lg-3 col-md-4 col-6">
            @component('frontend/microsite/product_item')
                <strong>Whoops!</strong> product_item
            @endcomponent
        </div>
        <div class="col-xxl-2 col-xl-2 col-lg-3 col-md-4 col-6">
            @component('frontend/microsite/product_item')
                <strong>Whoops!</strong> product_item
            @endcomponent
        </div>
        <div class="col-xxl-2 col-xl-2 col-lg-3 col-md-4 col-6">
            @component('frontend/microsite/product_item')
                <strong>Whoops!</strong> product_item
            @endcomponent
        </div>
        <div class="col-xxl-2 col-xl-2 col-lg-3 col-md-4 col-6">
            @component('frontend/microsite/product_item')
                <strong>Whoops!</strong> product_item
            @endcomponent
        </div>
        <div class="col-xxl-2 col-xl-2 col-lg-3 col-md-4 col-6">
            @component('frontend/microsite/product_item')
                <strong>Whoops!</strong> product_item
            @endcomponent
        </div>
        <div class="col-xxl-2 col-xl-2 col-lg-3 col-md-4 col-6">
            @component('frontend/microsite/product_item')
                <strong>Whoops!</strong> product_item
            @endcomponent
        </div>
        <div class="col-xxl-2 col-xl-2 col-lg-3 col-md-4 col-6">
            @component('frontend/microsite/product_item')
                <strong>Whoops!</strong> product_item
            @endcomponent
        </div>
        <div class="col-xxl-2 col-xl-2 col-lg-3 col-md-4 col-6">
            @component('frontend/microsite/product_item')
                <strong>Whoops!</strong> product_item
            @endcomponent
        </div>
        <div class="col-xxl-2 col-xl-2 col-lg-3 col-md-4 col-6">
            @component('frontend/microsite/product_item')
                <strong>Whoops!</strong> product_item
            @endcomponent
        </div>
        <div class="col-xxl-2 col-xl-2 col-lg-3 col-md-4 col-6">
            @component('frontend/microsite/product_item')
                <strong>Whoops!</strong> product_item
            @endcomponent
        </div>
        <div class="col-xxl-2 col-xl-2 col-lg-3 col-md-4 col-6">
            @component('frontend/microsite/product_item')
                <strong>Whoops!</strong> product_item
            @endcomponent
        </div>
        <div class="col-xxl-2 col-xl-2 col-lg-3 col-md-4 col-6">
            @component('frontend/microsite/product_item')
                <strong>Whoops!</strong> product_item
            @endcomponent
        </div>
    </div>

    <div class="products-pagination p-3">
        <nav aria-label="Center aligned pagination">
            <ul class="pagination justify-content-center">
                <nav>
                    <ul class="pagination">
                        <li class="page-item disabled" aria-disabled="true" aria-label="« Previous">
                            <span class="page-link" aria-hidden="true">‹</span>
                        </li>
                        <li class="page-item active" aria-current="page"><span class="page-link">1</span></li>
                        <li class="page-item"><a class="page-link" href="https://ysg.com.sg/search?q=a&amp;page=2">2</a></li>
                        <li class="page-item"><a class="page-link" href="https://ysg.com.sg/search?q=a&amp;page=3">3</a></li>
                        <li class="page-item disabled" aria-disabled="true"><span class="page-link">...</span></li>
                        <li class="page-item"><a class="page-link" href="https://ysg.com.sg/search?q=a&amp;page=45">45</a></li>
                        <li class="page-item"><a class="page-link" href="https://ysg.com.sg/search?q=a&amp;page=46">46</a></li>
                        <li class="page-item">
                            <a class="page-link" href="https://ysg.com.sg/search?q=a&amp;page=2" rel="next" aria-label="Next »">›</a>
                        </li>
                    </ul>
                </nav>

            </ul>
        </nav>
    </div>
</div>
