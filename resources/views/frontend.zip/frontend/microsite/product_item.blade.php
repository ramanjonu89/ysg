<div class="card product-box-1 mb-3">
    <div class="card-image">
        <a href="http://ysg.vm/product/long-wear-daily-sunscreen-spf40-pa--tsf005" class="d-block text-center">
            <img class="img-fit lazyloaded" src="http://ysg.vm/uploads/products/photos/TSF005-.1.jpg" data-src="http://ysg.vm/uploads/products/photos/TSF005-.1.jpg" alt="Long Wear Daily Sunscreen SPF40 PA+++">
        </a>
    </div>
    <div class="card-body p-0">
        <div class="px-3 py-2">
            <h2 class="product-title p-0">
                <a href="http://ysg.vm/product/long-wear-daily-sunscreen-spf40-pa--tsf005" class="text-truncate-1">
                    The Skin Firm
                </a>
            </h2>
            <div class="card-jfy-title"><a href="http://ysg.vm/product/long-wear-daily-sunscreen-spf40-pa--tsf005" style="color:#000">Long Wear Daily Sunscreen SPF40 PA+++</a></div>
        </div>
        <div class="price-bar row no-gutters">
            <div class="price col-md-7">
                <span class="product-price strong-600">$15.90</span>
            </div>
            <div class="col-md-5">
                <div class="star-rating star-rating-sm float-md-right">
                    <i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i>
                </div>
            </div>
        </div>
        <div class="cart-add d-flex">
            <button class="btn add-wishlist border-right" title="Add to Wishlist" onclick="addToWishList(251)">
                <i class="la la-heart-o"></i>
            </button>
            <button class="btn add-compare border-right" title="Add to Compare" onclick="addToCompare(251)">
                <i class="la la-refresh"></i>
            </button>
            <button type="button" class="btn btn-block btn-icon-left" onclick="showAddToCartModal(251)">
                <span class="d-none d-sm-inline-block">Add to cart</span><i class="la la-shopping-cart ml-2"></i>
            </button>
        </div>
    </div>
</div>
