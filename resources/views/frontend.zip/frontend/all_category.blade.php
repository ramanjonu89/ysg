@extends('frontend.layouts.app')
@section('content')
<div class="all-category-wrap py-4 gry-bg">
    <div class="sticky-top">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="bg-white all-category-menu">
                        <ul class="d-flex flex-wrap no-scrollbar">
                            @if(count($categories) > 12)
                            @for ($i = 0; $i < 11; $i++)
                            @if($categories[$i]->status == 1)
                                <li class="@php if($i == 0) echo '' @endphp">
                                    <a href="#{{ $i }}" class="row no-gutters align-items-center">
                                        <!-- <div class="col-md-3">
                                            <img loading="lazy"  class="cat-image" src="{{ my_asset($categories[$i]->icon) }}">
                                        </div>-->
                                        <div class="col-md-9">
                                            <div class="cat-name">{{ $categories[$i]->name }}</div>
                                        </div>
                                    </a>
                                </li>
                                @endif
                                @endfor
                                <li class="">
                                    <a href="#more" class="row no-gutters align-items-center">
                                        <div class="col-md-3">
                                            <i class="fa fa-ellipsis-h cat-icon"></i>
                                        </div>
                                        <div class="col-md-9">
                                            <div class="cat-name">{{ translate('More Categories')}}</div>
                                        </div>
                                    </a>
                                </li>
                                @else
                                @foreach ($categories as $key => $category)
                                @if ($category->status == 1)
                                <li class="@php if($key == 0) echo '' @endphp">
                                    <a href="#{{ $key }}" class="row no-gutters align-items-center">
                                        <!-- <div class="col-md-3">
                                            <img loading="lazy"  class="cat-image" src="{{ my_asset($category->icon) }}">
                                        </div>-->
                                        <div class="col-md-9">
                                            <div class="cat-name">{{  __($category->name) }}</div>
                                        </div>
                                    </a>
                                </li>
                                @endif
                                @endforeach
                                @endif
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="mt-4">
            <div class="container">
                @foreach ($categories as $key => $category)
                @php
                 $countersss = DB::select( DB::raw("select * from categories where id in (SELECT category_id FROM products a left join sellers b on a.user_id = b.user_id WHERE a.published = 1 and b.verification_status = 1) and status = 1 and id = $category->id") );
                                        @endphp
                                        @foreach ($countersss as $key1 => $counter)
                                        @php
                                           if ($counter->id == $category->id) {
                                          $got = 1;
                                           }else{
                                           $got = 0;
                                           }
                                        @endphp
                                        @php
                                        $brands = array();
                                        @endphp
                                        @if ( isset($got) )
                @if ($category->status == 1)
                @if(count($categories)>12 && $key == 11)
                <div class="mb-3 bg-white">
                    <div class="sub-category-menu " id="more">
                        <h3 class="category-name border-bottom pb-2"><a href="{{ route('products.category', $category->slug) }}">{{  __($category->name) }}</a></h3>
                        <div class="row">
                            @foreach ($category->subcategories as $key => $subcategory)
                            <div class="col-lg-4 col-6">
                                <h6 class="mb-3"><a href="{{ route('products.subcategory', $subcategory->slug) }}">{{  __($subcategory->name) }}</a></h6>
                                <ul class="mb-3">
                                    @foreach ($subcategory->subsubcategories as $key => $subsubcategory)
                                    <li class="w-100"><a href="{{ route('products.subsubcategory', $subsubcategory->slug) }}" >{{  __($subsubcategory->name) }}</a></li>
                                    @endforeach
                                </ul>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>
                @else
                <div class="mb-3 bg-white">
                    <div class="sub-category-menu @php if($key < 12) echo ''; @endphp" id="{{ $key }}">
                        <h3 class="category-name border-bottom pb-2"><b><a href="{{ route('products.category', $category->slug) }}" >{{  __($category->name) }}</a></b></h3>
                        <div class="row">
                        
                            
                            @foreach ($category->subcategories as $key => $subcategory)
                         @php
                  
                               $counters = DB::select( DB::raw("select * from sub_categories where id in (SELECT subcategory_id FROM products a left join sellers b on a.user_id = b.user_id WHERE a.published = 1 and b.verification_status = 1 and a.subcategory_id = $subcategory->id) and status = 1") );
                               // echo "select * from sub_sub_categories where id in (SELECT subsubcategory_id FROM products a left join sellers b on a.user_id = b.user_id WHERE a.published = 1 and b.verification_status = 1 and a.subsubcategory_id = $subsubcategory->id) and status = 1";
                            @endphp
                             @foreach ($counters as $key => $counter)
                            @if ($subcategory->status == 1)
                            <div class="col-lg-4 col-6">
                                <h5 class="mb-3" ><a href="{{ route('products.subcategory', $subcategory->slug) }}">{{  __($subcategory->name) }}</a></h5>
                                <ul class="mb-3">
                                    @foreach ($subcategory->subsubcategories as $key => $subsubcategory)
                                       @php
                  
                               $counters = DB::select( DB::raw("select * from sub_sub_categories where id in (SELECT subsubcategory_id FROM products a left join sellers b on a.user_id = b.user_id WHERE a.published = 1 and b.verification_status = 1 and a.subsubcategory_id = $subsubcategory->id) and status = 1") );
                              // echo "select * from sub_sub_categories where id in (SELECT subsubcategory_id FROM products a left join sellers b on a.user_id = b.user_id WHERE a.published = 1 and b.verification_status = 1 and a.subsubcategory_id = $subsubcategory->id) and status = 1";
                            @endphp
                             @foreach ($counters as $key => $counter)
                                    @if ($subsubcategory->status == 1)
                                    <h6 class="mb-3" > <li class="w-100"><a href="{{ route('products.subsubcategory', $subsubcategory->slug) }}" >{{  __($subsubcategory->name) }}</a></li></h6>
                                    @endif
                                    @endforeach
                                    @endforeach
                                </ul>
                            </div>
                            @endif
                           @endforeach
                            @endforeach
                        </div>
                    </div>
                </div>
                @endif
                @endif
                @endif
                 @endforeach
                @endforeach
            </div>
        </div>
         <div class="mt-4">
            <div class="container">
            <div class="col-lg-12">
                    <div class="section-title-1 clearfix">
                        <h3 class="heading-5 strong-700 mb-0 float-left">
                            <span class="mr-4">{{translate('Shop by Brands')}}</span>
                        </h3>
                        <ul class="float-right inline-links">
                            <li>
                                <a href="{{ route('brands.all') }}" class="">{{translate('View All Brands')}}</a>
                            </li>
                        </ul>
                    </div>
                    <div class="row gutters-5">
                        @foreach (\App\Brand::where('top', 1)->get() as $brand)
                        <div class="mb-3 col-6">
                            <a href="{{ URL::route('search', array('brand_ids' => [$brand->id] )) }}" class="bg-white border d-block c-base-2 box-2 icon-anim pl-2">
                                <div class="row align-items-center no-gutters">
                                    <div class="col-3 text-center">
                                        <img src="{{ my_asset('frontend/images/placeholder.jpg') }}" data-src="{{ my_asset($brand->logo) }}" alt="{{ __($brand->name) }}" class="img-fluid img lazyload">
                                    </div>
                                    <div class="info col-7">
                                        <div class="name text-truncate pl-3 py-4">{{ __($brand->name) }}</div>
                                    </div>
                                    <div class="col-2 text-center">
                                        <i class="la la-angle-right c-base-1"></i>
                                    </div>
                                </div>
                            </a>
                        </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endsection
