@extends('frontend.layouts.app')



@section('content')



<div id="page-content">

   <section class="slice-xs sct-color-2 border-bottom">

        <div class="container container-sm">

            <div class="row cols-delimited justify-content-center">

                <div class="col">

                    <div class="icon-block icon-block--style-1-v5 text-center ">

                        <div class="block-icon c-gray-light mb-0">

                            <i class="la la-shopping-cart"></i>

                        </div>

                        <div class="block-content d-none d-md-block">

                            <h3 class="heading heading-sm strong-300 c-gray-light text-capitalize">{{ translate('1. My Cart')}}</h3>

                        </div>

                    </div>

                </div>

                

                <div class="col">

                    <div class="icon-block icon-block--style-1-v5 text-center active">

                        <div class="block-icon mb-0">

                            <i class="la la-map-o"></i>

                        </div>

                        <div class="block-content d-none d-md-block">

                            <h3 class="heading heading-sm strong-300 c-gray-light text-capitalize">{{ translate('2. Shipping info')}}</h3>

                        </div>

                    </div>

                </div>

                

                <div class="col">

                    <div class="icon-block icon-block--style-1-v5 text-center">

                        <div class="block-icon mb-0 c-gray-light">

                            <i class="la la-truck"></i>

                        </div>

                        <div class="block-content d-none d-md-block">

                            <h3 class="heading heading-sm strong-300 c-gray-light text-capitalize">{{ translate('3. Delivery info')}}</h3>

                        </div>

                    </div>

                </div>

                

                <div class="col">

                    <div class="icon-block icon-block--style-1-v5 text-center">

                        <div class="block-icon c-gray-light mb-0">

                            <i class="la la-credit-card"></i>

                        </div>

                        <div class="block-content d-none d-md-block">

                            <h3 class="heading heading-sm strong-300 c-gray-light text-capitalize">{{ translate('4. Payment')}}</h3>

                        </div>

                    </div>

                </div>

                

                <div class="col">

                    <div class="icon-block icon-block--style-1-v5 text-center">

                        <div class="block-icon c-gray-light mb-0">

                            <i class="la la-check-circle"></i>

                        </div>

                        <div class="block-content d-none d-md-block">

                            <h3 class="heading heading-sm strong-300 c-gray-light text-capitalize">{{ translate('5. Confirmation')}}</h3>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </section> 

    

    <section class="py-4 gry-bg">

        <div class="container">

            <div class="row cols-xs-space cols-sm-space cols-md-space">

                <div class="col-lg-8">

                    <form class="form-default" data-toggle="validator" action="{{ route('checkout.store_shipping_infostore') }}" role="form" method="POST">

                    <!-- <form action="{{ route('payment.checkout') }}" class="form-default" data-toggle="validator" role="form" method="POST" id="checkout-form">-->

                        @csrf

                        @if(Auth::check())

                        <div class="row gutters-5">

                            @foreach (Auth::user()->addresses as $key => $address)

                            <div class="col-md-6">

                                <label class="aiz-megabox d-block bg-white">

                                    <input type="radio" name="address_id" value="{{ $address->id }}" @if ($address->set_default)

                                    checked

                                    @endif required>

                                    <span class="d-flex p-3 aiz-megabox-elem">

                                        <span class="aiz-rounded-check flex-shrink-0 mt-1"></span>

                                        <span class="flex-grow-1 pl-3">

                                            <div>

                                                <span class="alpha-6">{{ translate('Street Name') }}:</span>

                                                <span class="strong-600 ml-2">{{ $address->address }}</span>

                                            </div>

                                            <div>

                                                <span class="alpha-6">{{ translate('Postal Code') }}:</span>

                                                <span class="strong-600 ml-2">{{ $address->postal_code }}</span>

                                            </div>

                                            <div>

                                                <span class="alpha-6">{{ translate('City') }}:</span>

                                                <span class="strong-600 ml-2">{{ $address->city }}</span>

                                            </div>

                                            <div>

                                                <span class="alpha-6">{{ translate('Country') }}:</span>

                                                <span class="strong-600 ml-2">{{ $address->country }}</span>

                                            </div>

                                            <div>

                                                <span class="alpha-6">{{ translate('Phone') }}:</span>

                                                <span class="strong-600 ml-2">{{ $address->phone }}</span>

                                            </div>

                                        </span>

                                    </span>

                                </label>

                            </div>

                            @endforeach

                            <input type="hidden" name="checkout_type" value="logged">

                            <div class="col-md-6 mx-auto" onclick="add_new_address()">

                                <div class="border p-3 rounded mb-3 c-pointer text-center bg-white">

                                    <i class="la la-plus la-2x"></i>

                                    <div class="alpha-7">{{ translate('Add New Address') }}</div>

                                </div>

                            </div>

                        </div>

                        @else

                        <div class="card">

                            <div class="card-body">

                                <div class="row">

                                    <div class="col-md-12">

                                        <div class="form-group">

                                            <label class="control-label">{{ translate('Name')}}</label>

                                            <input type="text" class="form-control" name="name" placeholder="{{ translate('Name')}}" required>

                                        </div>

                                    </div>

                                </div>

                                

                                <div class="row">

                                    <div class="col-md-12">

                                        <div class="form-group">

                                            <label class="control-label">{{ translate('Email')}}</label>

                                            <input type="text" class="form-control" name="email" placeholder="{{ translate('Email')}}" required>

                                        </div>

                                    </div>

                                </div>

                                

                                <div class="row">

                                    <div class="col-md-12">

                                        <div class="form-group">

                                            <label class="control-label">{{ translate('Street Name')}}</label>

                                            <input type="text" class="form-control" name="address" placeholder="{{ translate('Address')}}" required>

                                        </div>

                                    </div>

                                </div>

                                

                                <div class="row">

                                    <div class="col-md-6">

                                        <div class="form-group">

                                            <label class="control-label">{{ translate('Select your country')}}</label>

                                            <select class="form-control custome-control" data-live-search="true" name="country">

                                                @foreach (\App\Country::where('status', 1)->get() as $key => $country)

                                                <option value="{{ $country->name }}">{{ $country->name }}</option>

                                                @endforeach

                                            </select>

                                        </div>

                                    </div>

                                    <div class="col-md-6">

                                        <div class="form-group has-feedback">

                                            <label class="control-label">{{ translate('City')}}</label>

                                            <input type="text" class="form-control" placeholder="{{ translate('City')}}" name="city" required>

                                        </div>

                                    </div>

                                </div>

                                

                                <div class="row">

                                    <div class="col-md-6">

                                        <div class="form-group has-feedback">

                                            <label class="control-label">{{ translate('Postal code')}}</label>

                                            <input type="text" class="form-control" placeholder="{{ translate('Postal code')}}" name="postal_code" required>

                                        </div>

                                    </div>

                                    <div class="col-md-6">

                                        <div class="form-group has-feedback">

                                            <label class="control-label">{{ translate('Phone')}}</label>

                                            <input type="number" min="0" class="form-control" placeholder="{{ translate('Phone')}}" name="phone" required>

                                        </div>

                                    </div>

                                </div>

                                <input type="hidden" name="checkout_type" value="guest">

                            </div>

                        </div>

                        @endif

                        <div class="row align-items-center pt-4">

                            <div class="col-md-6">

                                <a href="/cart" class="link link--style-3">

                                    <i class="ion-android-arrow-back"></i>

                                    {{ translate('Back')}}

                                </a>

                            </div>

                            <div class="col-md-6 text-right">

                                <button type="submit" class="btn btn-styled btn-base-1">{{ translate('Continue to Delivery Info')}}</a>

                            </div>

                        </div>

                    </form>

                </div>

                

                <div class="col-lg-4 ml-lg-auto">

                    @include('frontend.partials.cart_summary')

                   

                                                   

                                       

                </div>

            </div>

        </div>

    </section>

</div>



<div class="modal fade" id="new-address-modal" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">

     <script

      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAosfQaV0y5nZdj8Ih5qNEqT8gBT8hgqic&callback=initAutocomplete&libraries=places&v=weekly"

      defer

    ></script>



        <script>



let placeSearch;

let autocomplete;

const componentForm = {

  

  postal_code: "short_name",

};



function initAutocomplete() {

  // Create the autocomplete object, restricting the search predictions to



  // geographical location types.

  autocomplete = new google.maps.places.Autocomplete(

    document.getElementById("autocomplete"),

    { types: ["geocode"] }

  );

  // Avoid paying for data that you don't need by restricting the set of

  // place fields that are returned to just the address components.

  autocomplete.setFields(["address_component"]);

  // When the user selects an address from the drop-down, populate the

  // address fields in the form.

  autocomplete.addListener("place_changed", fillInAddress);

}



function fillInAddress() {

  // Get the place details from the autocomplete object.

  const place = autocomplete.getPlace();



  for (const component in componentForm) {

    document.getElementById(component).value = "";

    document.getElementById(component).disabled = false;

  }



  // Get each component of the address from the place details,

  // and then fill-in the corresponding field on the form.

  for (const component of place.address_components) {

    const addressType = component.types[0];



    if (componentForm[addressType]) {

      const val = component[componentForm[addressType]];

      document.getElementById(addressType).value = val;

    }

  }

}



// Bias the autocomplete object to the user's geographical location,

// as supplied by the browser's 'navigator.geolocation' object.

function geolocate() {

    console.log("lol");

  if (navigator.geolocation) {

    navigator.geolocation.getCurrentPosition((position) => {

      const geolocation = {

        lat: position.coords.latitude,

        lng: position.coords.longitude,

      };

      const circle = new google.maps.Circle({

        center: geolocation,

        radius: position.coords.accuracy,

      });

      autocomplete.setBounds(circle.getBounds());

    });

  }

}

        </script>

    <div class="modal-dialog modal-dialog-zoom" role="document">

        <div class="modal-content">

            <div class="modal-header">

                <h6 class="modal-title" id="exampleModalLabel">{{ translate('New Shipping Address')}}</h6>

                <button type="button" class="close" data-dismiss="modal" aria-label="Close">

                    <span aria-hidden="true">&times;</span>

                </button>

            </div>

            <form class="form-default" role="form" action="{{ route('addresses.store') }}" method="POST">

                @csrf

                <div class="modal-body">

                    <div class="p-3">

                        <div class="row">

                            <div class="col-md-4">

                                <label>{{ translate('Shipping Address')}}</label>

                            </div>

                            <div class="col-md-8">

                                <textarea class="form-control textarea-autogrow mb-3 " id="autocomplete" placeholder="{{ translate('Your Address')}}" rows="2" name="address" required></textarea>

                            </div>

                        </div>

                        

                        <div class="row">

                            <div class="col-md-4">

                                <label>{{ translate('Unit No.')}}</label>

                            </div>

                            <div class="col-md-8">

                               <input type="text" class="form-control mb-3" placeholder="{{ translate('e.g. 09-11')}}" name="unitno" value="" required>

                            </div>

                        </div>

                      

                          

                        

                        <div class="row" id="address">

                            <div class="col-md-4">

                                <label>{{ translate('Country')}}</label>

                            </div>

                            <div class="col-md-8">

                                <div class="mb-3">

                                    <select class="form-control mb-3 selectpicker" data-placeholder="{{ translate('Select your country')}}" name="country"  required>

                                        @foreach (\App\Country::where('status', 1)->get() as $key => $country)

                                        <option value="{{ $country->name }}">{{ $country->name }}</option>

                                        @endforeach

                                    </select>

                                </div>

                            </div>

                        </div>

                        <div class="row" style="display:none">

                            <div class="col-md-2">

                                <label>{{ translate('City')}}</label>

                            </div>

                            <div class="col-md-10">

                                <input type="text" class="form-control mb-3" placeholder="{{ translate('Your City')}}" name="city" value="Singapore" required>

                            </div>

                        </div>

                        <div class="row">

                            <div class="col-md-4">

                                <label>{{ translate('Postal code')}}</label>

                            </div>

                            <div class="col-md-8">

                                <input type="text" class="form-control mb-3" placeholder="{{ translate('Your Postal Code')}}" id="postal_code" name="postal_code" value="" required>

                            </div>

                        </div>

                        <div class="row">

                            <div class="col-md-4">

                                <label>{{ translate('Phone')}}</label>

                            </div>

                            <div class="col-md-8">

                                <input type="text" class="form-control mb-3" placeholder="{{ translate('+65')}}" name="phone" value="" required>

                            </div>

                        </div>

                    </div>

                </div>

                <div class="modal-footer">

                    <button type="submit" class="btn btn-base-1">{{  translate('Save') }}</button>

                </div>

            </form>

        </div>

    </div>

</div>









@endsection



@section('script')

<script type="text/javascript">

    function add_new_address(){

        $('#new-address-modal').modal('show');

    }

</script>



@endsection

<style>

    .pac-container {

        z-index: 10000 !important;

    }

</style>