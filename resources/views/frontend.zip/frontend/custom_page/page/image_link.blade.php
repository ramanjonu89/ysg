<div class="block image_link">
    <div class="wrap">
        @foreach($block->blockContents as $blockContent)
            <div class="block-content">
                <a href="{{$blockContent->options->link}}">
                    <img src="{{$blockContent->image}}" alt="{{$blockContent->title}}" class="width-100">
                </a>
            </div>
        @endforeach
    </div>
</div>
