<div class="block banner">
    <p>
        <a href="{{$block->options->link}}">
            <img src="{{$block->image}}" alt="{{$block->title}}" class="width-100">
        </a>
    </p>
</div>
