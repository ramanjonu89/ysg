<div class="block image_link">
    <div class="wrap container">
        @php
            $sellers = resolve('BlockService')->getListCorporateSeller($block);
        @endphp
        <div class="row">
            @foreach($sellers as $seller)
                <div class="col-6" style="padding: 0.1rem;">
                    <a href="{{ route('shop.visit', $seller->user->shop->slug) }}">
                        <img src="{{$seller->image??url('/assets/img/sellers/shop-logo.jpg')}}" alt="{{$seller->user->name}}" class="width-100">
                    </a>
                </div>
            @endforeach
        </div>
    </div>
</div>
