@extends('frontend.layouts.app')



@section('content')



<section class="gry-bg py-4 profile">

    <div class="container">

        <div class="row cols-xs-space cols-sm-space cols-md-space">

            <div class="col-lg-3 d-none d-lg-block">

                @if(Auth::user()->user_type == 'seller')

                @include('frontend.inc.seller_side_nav')

                @elseif(Auth::user()->user_type == 'customer')

                @include('frontend.inc.customer_side_nav')

                @endif

            </div>

            

            <div class="col-lg-9">

                <div class="main-content">

                    <!-- Page title -->

                    <div class="page-title">

                        <div class="row align-items-center">

                            <div class="col-md-6 col-12">

                                <h2 class="heading heading-6 text-capitalize strong-600 mb-0">

                                    {{ translate('Manage Profile') }}

                                </h2>

                            </div>

                            <div class="col-md-6 col-12">

                                <div class="float-md-right">

                                    <ul class="breadcrumb">

                                        <li><a href="{{ route('home') }}">{{ translate('Home') }}</a></li>

                                        <li><a href="{{ route('dashboard') }}">{{ translate('Dashboard') }}</a></li>

                                        <li class="active"><a href="{{ route('profile') }}">{{ translate('Manage Profile') }}</a></li>

                                    </ul>

                                </div>

                            </div>

                        </div>

                    </div>

                    <form class="" action="{{ route('customer.profile.update') }}" method="POST" enctype="multipart/form-data">

                        @csrf

                        <div class="form-box bg-white mt-4">

                            <div class="form-box-title px-3 py-2">

                                {{ translate('Basic info') }}

                            </div>

                            <div class="form-box-content p-3">

                                <div class="row">

                                    <div class="col-md-2">

                                        <label>{{ translate('Your Name') }}</label>

                                    </div>

                                    <div class="col-md-10">

                                        <input type="text" class="form-control mb-3" placeholder="{{ translate('Your Name') }}" name="name" value="{{ Auth::user()->name }}">

                                    </div>

                                </div>

                                

                                <div class="row">

                                    <div class="col-md-2">

                                        <label>{{ translate('Your Phone')}}</label>

                                    </div>

                                    <div class="col-md-10">

                                        <input type="text" class="form-control mb-3" placeholder="{{ translate('Your Phone')}}" name="phone" value="{{ Auth::user()->phone }}">

                                    </div>

                                </div>

                                <div class="row">

                                    <div class="col-md-2">

                                        <label>{{ translate('Photo') }}</label>

                                    </div>

                                    <div class="col-md-10">

                                        <input type="file" name="photo" id="file-3" class="custom-input-file custom-input-file--4" data-multiple-caption="{count} files selected" accept="image/*" />

                                        <label for="file-3" class="mw-100 mb-3">

                                            <span></span>

                                            <strong>

                                                <i class="fa fa-upload"></i>

                                                {{ translate('Choose image') }}

                                            </strong>

                                        </label>

                                    </div>

                                </div>

                                <div class="row">

                                    <div class="col-md-2">

                                        <label>{{ translate('Your Password') }}</label>

                                    </div>

                                    <div class="col-md-10">

                                        <input type="password" class="form-control mb-3" placeholder="{{ translate('New Password') }}" name="new_password">

                                    </div>

                                </div>

                                <div class="row">

                                    <div class="col-md-2">

                                        <label>{{ translate('Confirm Password') }}</label>

                                    </div>

                                    <div class="col-md-10">

                                        <input type="password" class="form-control mb-3" placeholder="{{ translate('Confirm Password') }}" name="confirm_password">

                                    </div>

                                </div>

                            </div>

                        </div>

                        

                        <div class="text-right mt-4">

                            <button type="submit" class="btn btn-styled btn-base-1">{{ translate('Update Profile') }}</button>

                        </div>

                        

                        <div class="form-box bg-white mt-4">

                            <div class="form-box-title px-3 py-2">

                                {{ translate('Addresses') }}

                            </div>

                            <div class="form-box-content p-3">

                                <div class="row gutters-10">

                                    @foreach (Auth::user()->addresses as $key => $address)

                                    <div class="col-lg-6">

                                        <div class="border p-3 pr-5 rounded mb-3 position-relative">

                                            <div>

                                                <span class="alpha-6">{{ translate('Address') }}:</span>

                                                <span class="strong-600 ml-2">{{ $address->address }}</span>

                                            </div>

                                            <div>

                                                <span class="alpha-6">{{ translate('Postal Code') }}:</span>

                                                <span class="strong-600 ml-2">{{ $address->postal_code }}</span>

                                            </div>

                                            <div>

                                                <span class="alpha-6">{{ translate('City') }}:</span>

                                                <span class="strong-600 ml-2">{{ $address->city }}</span>

                                            </div>

                                            <div>

                                                <span class="alpha-6">{{ translate('Country') }}:</span>

                                                <span class="strong-600 ml-2">{{ $address->country }}</span>

                                            </div>

                                            <div>

                                                <span class="alpha-6">{{ translate('Phone') }}:</span>

                                                <span class="strong-600 ml-2">{{ $address->phone }}</span>

                                            </div>

                                            @if ($address->set_default)

                                            <div class="position-absolute right-0 bottom-0 pr-2 pb-3">

                                                <span class="badge badge-primary bg-base-1">{{ translate('Default') }}</span>

                                            </div>

                                            @endif

                                            <div class="dropdown position-absolute right-0 top-0">

                                                <button class="btn bg-gray px-2" type="button" data-toggle="dropdown">

                                                    <i class="la la-ellipsis-v"></i>

                                                </button>

                                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton">

                                                    @if (!$address->set_default)

                                                    <a class="dropdown-item" href="{{ route('addresses.set_default', $address->id) }}">{{ translate('Make This Default') }}</a>

                                                    @endif

                                                    {{-- <a class="dropdown-item" href="">Edit</a> --}}

                                                    <a class="dropdown-item" href="{{ route('addresses.destroy', $address->id) }}">{{ translate('Delete') }}</a>

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                    @endforeach

                                    <div class="col-lg-6 mx-auto" onclick="add_new_address()">

                                        <div class="border p-3 rounded mb-3 c-pointer text-center bg-light">

                                            <i class="la la-plus la-2x"></i>

                                            <div class="alpha-7">{{ translate('Add New Address') }}</div>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                        

                    </form>

                    

                    <form action="{{ route('user.change.email') }}" method="POST">

                        @csrf

                        <div class="form-box bg-white mt-4">

                            <div class="form-box-title px-3 py-2">

                                {{ translate('Change your email') }}

                            </div>

                            <div class="form-box-content p-3">

                                <div class="row">

                                    <div class="col-md-2">

                                        <label>{{ translate('Your Email') }}</label>

                                    </div>

                                    <div class="col-md-10">

                                        <div class="input-group mb-3">

                                            <input

                                            type="email"

                                            class="form-control"

                                            placeholder="{{ translate('Your Email')}}"

                                            name="email"

                                            value=

                                            "{{ Auth::user()->email }}"

                                            />

                                            <div class="input-group-append">

                                                <button type="button" class="btn btn-outline-secondary new-email-verification">

                                                    <span class="d-none loading">

                                                        <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>

                                                        Sending Email...

                                                    </span>

                                                    <span class="default">Verify</span>

                                                </button>

                                            </div>

                                        </div>

                                        <button class="btn btn-styled btn-base-1" type="submit">Update Email</button>

                                    </div>

                                </div>

                            </div>

                        </div>

                    </form>

                </div>

            </div>

        </div>

    </div>

</section>



<div class="modal fade" id="new-address-modal" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">

    <script

    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAosfQaV0y5nZdj8Ih5qNEqT8gBT8hgqic&callback=initAutocomplete&libraries=places&v=weekly"

    defer

    ></script>

    

    <script>

        

        let placeSearch;

        let autocomplete;

        const componentForm = {

        

        postal_code: "short_name",

        };

        

        function initAutocomplete() {

        // Create the autocomplete object, restricting the search predictions to

        

        // geographical location types.

        autocomplete = new google.maps.places.Autocomplete(

        document.getElementById("autocomplete"),

        { types: ["geocode"] }

        );

        // Avoid paying for data that you don't need by restricting the set of

        // place fields that are returned to just the address components.

        autocomplete.setFields(["address_component"]);

        // When the user selects an address from the drop-down, populate the

        // address fields in the form.

        autocomplete.addListener("place_changed", fillInAddress);

        }

        

        function fillInAddress() {

        // Get the place details from the autocomplete object.

        const place = autocomplete.getPlace();

        

        for (const component in componentForm) {

        document.getElementById(component).value = "";

        document.getElementById(component).disabled = false;

        }

        

        // Get each component of the address from the place details,

        // and then fill-in the corresponding field on the form.

        for (const component of place.address_components) {

        const addressType = component.types[0];

        

        if (componentForm[addressType]) {

        const val = component[componentForm[addressType]];

        document.getElementById(addressType).value = val;

        }

        }

        }

        

        // Bias the autocomplete object to the user's geographical location,

        // as supplied by the browser's 'navigator.geolocation' object.

        function geolocate() {

        console.log("lol");

        if (navigator.geolocation) {

        navigator.geolocation.getCurrentPosition((position) => {

        const geolocation = {

        lat: position.coords.latitude,

        lng: position.coords.longitude,

        };

        const circle = new google.maps.Circle({

        center: geolocation,

        radius: position.coords.accuracy,

        });

        autocomplete.setBounds(circle.getBounds());

        });

        }

        }

    </script>

    <div class="modal-dialog modal-dialog-zoom" role="document">

        <div class="modal-content">

            <div class="modal-header">

                <h6 class="modal-title" id="exampleModalLabel">{{ translate('New Address') }}</h6>

                <button type="button" class="close" data-dismiss="modal" aria-label="Close">

                    <span aria-hidden="true">&times;</span>

                </button>

            </div>

            <form class="form-default" role="form" action="{{ route('addresses.store') }}" method="POST">

                @csrf

                <div class="modal-body">

                    <div class="p-3">

                        <div class="row">

                            <div class="col-md-4">

                                <label>{{ translate('Shipping Address') }}</label>

                            </div>

                            <div class="col-md-8">

                               

                                 <textarea class="form-control textarea-autogrow mb-3 " id="autocomplete" placeholder="{{ translate('Your Address')}}" rows="2" name="address" required></textarea>

                            </div>

                        </div>

                        <div class="row">

                            <div class="col-md-4">

                                <label>{{ translate('Unit No.')}}</label>

                            </div>

                            <div class="col-md-8">

                                <input type="text" class="form-control mb-3" placeholder="{{ translate('e.g. 09-11')}}" name="unitno" value="" required>

                            </div>

                        </div>

                        <div class="row">

                            <div class="col-md-4">

                                <label>{{ translate('Country') }}</label>

                            </div>

                            <div class="col-md-8">

                                <div class="mb-3">

                                    <select class="form-control mb-3 selectpicker" data-placeholder="{{translate('Select your country')}}" name="country" required>

                                        @foreach (\App\Country::where('status', 1)->get() as $key => $country)

                                        <option value="{{ $country->name }}">{{ $country->name }}</option>

                                        @endforeach

                                    </select>

                                </div>

                            </div>

                        </div>

                        <div class="row" style="display:none">

                            <div class="col-md-2">

                                <label>{{ translate('City')}}</label>

                            </div>

                            <div class="col-md-10">

                                <input type="text" class="form-control mb-3" placeholder="{{ translate('Your City')}}" name="city" value="Singapore" required>

                            </div>

                        </div>

                        <div class="row">

                            <div class="col-md-4">

                                <label>{{ translate('Postal code')}}</label>

                            </div>

                            <div class="col-md-8">

                                <input type="text" class="form-control mb-3" placeholder="{{ translate('Your Postal Code')}}" id="postal_code" name="postal_code" value="" required>

                            </div>

                        </div>

                        <div class="row">

                            <div class="col-md-4">

                                <label>{{ translate('Phone')}}</label>

                            </div>

                            <div class="col-md-8">

                                <input type="text" class="form-control mb-3" placeholder="{{ translate('Your phone number')}}" name="phone" value="" required>

                            </div>

                        </div>

                    </div>

                </div>

                <div class="modal-footer">

                    <button type="submit" class="btn btn-base-1">{{  translate('Save') }}</button>

                </div>

            </form>

        </div>

    </div>

</div>



@endsection



@section('script')

<script type="text/javascript">

    function add_new_address(){

        $('#new-address-modal').modal('show');

    }

    

$('.new-email-verification').on('click', function() {

$(this).find('.loading').removeClass('d-none');

$(this).find('.default').addClass('d-none');

var email = $("input[name=email]").val();



$.post('{{ route('user.new.verify') }}', {_token:'{{ csrf_token() }}', email: email}, function(data){

data = JSON.parse(data);

$('.default').removeClass('d-none');

$('.loading').addClass('d-none');

if(data.status == 2)

showFrontendAlert('warning', data.message);

else if(data.status == 1)

showFrontendAlert('success', data.message);

else

showFrontendAlert('danger', data.message);

});

});

</script>

@endsection

<style>

    .pac-container {

        z-index: 10000 !important;

    }

</style>