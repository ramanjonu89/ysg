@extends('frontend.layouts.app')



@section('content')



    <section class="gry-bg py-4 profile">

        <div class="container">

            <div class="row cols-xs-space cols-sm-space cols-md-space">

                <div class="col-lg-3 d-none d-lg-block">

                    @include('frontend.inc.seller_side_nav')

                </div>



                <div class="col-lg-9">

                    <div class="main-content">

                        <!-- Page title -->

                        <div class="page-title">

                            <div class="row align-items-center">

                                <div class="col-md-6">

                                    <h2 class="heading heading-6 text-capitalize strong-600 mb-0">

                                        {{ translate('Shop Settings')}}

                                        <a href="{{ route('shop.visit', $shop->slug) }}" class="btn btn-link btn-sm" target="_blank">({{ translate('Visit Shop')}})<i class="la la-external-link"></i>)</a>

                                    </h2>

                                </div>

                                <div class="col-md-6">

                                    <div class="float-md-right">

                                        <ul class="breadcrumb">

                                            <li><a href="{{ route('home') }}">{{ translate('Home')}}</a></li>

                                            <li><a href="{{ route('dashboard') }}">{{ translate('Dashboard')}}</a></li>

                                            <li class="active"><a href="{{ route('shops.index') }}">{{ translate('Shop Settings')}}</a></li>

                                        </ul>

                                    </div>

                                </div>

                            </div>

                        </div>

                        <form class="" action="{{ route('shops.update', $shop->id) }}" method="POST" enctype="multipart/form-data">

                            <input type="hidden" name="_method" value="PATCH">

                            @csrf

                            <div class="form-box bg-white mt-4">

                                <div class="form-box-title px-3 py-2">

                                    {{ translate('Basic info')}}

                                </div>

                                <div class="form-box-content p-3">

                                    <div class="row">

                                        <div class="col-md-2">

                                            <label>{{ translate('Shop Name')}} <span class="required-star">*</span></label>

                                        </div>

                                        <div class="col-md-10">

                                            <input type="text" class="form-control mb-3" placeholder="{{ translate('Shop Name')}}" name="name" value="{{ $shop->name }}" required>

                                        </div>

                                    </div>

                                    @if (\App\BusinessSetting::where('type', 'shipping_type')->first()->value == 'seller_wise_shipping')

                                        <div class="row">

                                            <div class="col-md-2">

                                                <label>{{ translate('Shipping Cost')}} <span class="required-star">*</span></label>

                                            </div>

                                            <div class="col-md-10">

                                                <input type="number" min="0" class="form-control mb-3" placeholder="{{ translate('Shipping Cost')}}" name="shipping_cost" value="{{ $shop->shipping_cost }}" required>

                                            </div>

                                        </div>

                                        <div class="row">

                                            <div class="col-md-2">

                                                <label>{{ translate('Free Shipping above')}} <span class="required-star">*</span></label>

                                            </div>

                                            <div class="col-md-10">

                                                <input type="number" min="0" class="form-control mb-3" placeholder="{{ translate('e.g 100')}}" name="shipping_cost_above" value="{{ $shop->shipping_cost_above }}" required>

                                            </div>

                                        </div>

                                    @endif

                                    <!--<div class="row mb-3">

                                        <div class="col-md-2">

                                            <label>{{ translate('Pickup Points')}} <span class="required-star"></span></label>

                                        </div>

                                        <div class="col-md-10">

                                            <select class="form-control mb-3 selectpicker" data-placeholder="{{ translate('Select Pickup Point') }}" id="pick_up_point" name="pick_up_point_id[]" multiple>

                                                @foreach (\App\PickupPoint::all() as $pick_up_point)

                                                    @if (Auth::user()->shop->pick_up_point_id != null)

                                                        <option value="{{ $pick_up_point->id }}" @if (in_array($pick_up_point->id, json_decode(Auth::user()->shop->pick_up_point_id))) selected @endif>{{ $pick_up_point->name }}</option>

                                                    @else

                                                        <option value="{{ $pick_up_point->id }}">{{ $pick_up_point->name }}</option>

                                                    @endif

                                                @endforeach

                                            </select>

                                        </div>

                                    </div>-->

                                    <div class="row">

                                        <div class="col-md-2">

                                            <label>{{ translate('Logo')}} <small>({{ translate('120x120')}})</small></label>

                                        </div>

                                        <div class="col-md-10">

                                            <input type="file" name="logo" id="file-2" class="custom-input-file custom-input-file--4" data-multiple-caption="{count} files selected" accept="image/*" />

                                            <label for="file-2" class="mw-100 mb-3">

                                                <span></span>

                                                <strong>

                                                    <i class="fa fa-upload"></i>

                                                    {{ translate('Choose image')}}

                                                </strong>

                                            </label>

                                        </div>

                                    </div>

                                    <div class="row">

                                        <div class="col-md-2">

                                            <label>{{ translate('Address')}} <span class="required-star">*</span></label>

                                        </div>

                                        <div class="col-md-10">

                                            <input type="text" class="form-control mb-3" placeholder="{{ translate('Address')}}" name="address" value="{{ $shop->address }}" required>

                                        </div>

                                    </div>

                                    <div class="row">

                                        <div class="col-md-2">

                                            <label>{{ translate('Meta Title')}} <span class="required-star">*</span></label>

                                        </div>

                                        <div class="col-md-10">

                                            <input type="text" class="form-control mb-3" placeholder="{{ translate('Meta Title')}}" name="meta_title" value="{{ $shop->meta_title }}" required>

                                        </div>

                                    </div>

                                    <div class="row">

                                        <div class="col-md-2">

                                            <label>{{ translate('Meta Description')}} <span class="required-star">*</span></label>

                                        </div>

                                        <div class="col-md-10">

                                            <textarea name="meta_description" rows="6" class="form-control mb-3" required>{{ $shop->meta_description }}</textarea>

                                        </div>

                                    </div>

                                </div>

                            </div>

                            <div class="text-right mt-4">

                                <button type="submit" class="btn btn-styled btn-base-1">{{ translate('Save')}}</button>

                            </div>

                        </form>



                        <form class="" action="{{ route('shops.update', $shop->id) }}" method="POST" enctype="multipart/form-data">

                            <input type="hidden" name="_method" value="PATCH">

                            @csrf

                            <div class="form-box bg-white mt-4">

                                <div class="form-box-title px-3 py-2">

                                    {{ translate('Slider Settings')}}

                                </div>

                                <div class="form-box-content p-3">

                                    <div id="shop-slider-images">

                                        <div class="row">

                                            <div class="col-md-2">

                                                <label>{{ translate('Slider Images')}} <small>(1400x400)</small></label>

                                            </div>

                                            <div class="offset-2 offset-md-0 col-10 col-md-10">

                                                <div class="row">

                                                    @if ($shop->sliders != null)

                                                        @foreach (json_decode($shop->sliders) as $key => $sliders)

                                                            <div class="col-md-6">

                                                                <div class="img-upload-preview">

                                                                    <img loading="lazy"  src="{{ my_asset($sliders) }}" alt="" class="img-fluid">

                                                                    <input type="hidden" name="previous_sliders[]" value="{{ $sliders }}">

                                                                    <button type="button" class="btn btn-danger close-btn remove-files"><i class="fa fa-times"></i></button>

                                                                </div>

                                                            </div>

                                                        @endforeach

                                                    @endif

                                                </div>

                                                <input type="file" name="sliders[]" id="slide-0" class="custom-input-file custom-input-file--4" data-multiple-caption="{count} files selected" multiple accept="image/*" />

                                                <label for="slide-0" class="mw-100 mb-3">

                                                    <span></span>

                                                    <strong>

                                                        <i class="fa fa-upload"></i>

                                                        {{ translate('Choose image')}}

                                                    </strong>

                                                </label>

                                            </div>

                                        </div>

                                    </div>

                                    <div class="text-right">

                                        <button type="button" class="btn btn-info mb-3" onclick="add_more_slider_image()">{{  translate('Add More') }}</button>

                                    </div>

                                </div>

                            </div>

                            <div class="text-right mt-4">

                                <button type="submit" class="btn btn-styled btn-base-1">{{ translate('Save')}}</button>

                            </div>

                        </form>



                        <form class="" action="{{ route('shops.update', $shop->id) }}" method="POST" enctype="multipart/form-data">

                            <input type="hidden" name="_method" value="PATCH">

                            @csrf

                            <div class="form-box bg-white mt-4">

                                <div class="form-box-title px-3 py-2">

                                    {{ translate('Social Media Link')}}

                                </div>

                                <div class="form-box-content p-3">

                                    <div class="row">

                                        <div class="col-md-2">

                                            <label ><i class="line-height-1_8 size-24 mr-2 fa fa-facebook bg-facebook c-white text-center"></i>{{ translate('Facebook')}} </label>

                                        </div>

                                        <div class="col-md-10">

                                            <input type="text" class="form-control mb-3" placeholder="{{ translate('Facebook')}}" name="facebook" value="{{ $shop->facebook }}">

                                        </div>

                                    </div>

                                    <div class="row">

                                        <div class="col-md-2">

                                            <label><i class="line-height-1_8 size-24 mr-2 fa fa-twitter bg-twitter c-white text-center"></i>{{ translate('Twitter')}} </label>

                                        </div>

                                        <div class="col-md-10">

                                            <input type="text" class="form-control mb-3" placeholder="{{ translate('Twitter')}}" name="twitter" value="{{ $shop->twitter }}">

                                        </div>

                                    </div>

                                    <div class="row">

                                        <div class="col-md-2">

                                            <label><i class="line-height-1_8 size-24 mr-2 fa fa-google bg-google c-white text-center"></i>{{ translate('Google')}} </label>

                                        </div>

                                        <div class="col-md-10">

                                            <input type="text" class="form-control mb-3" placeholder="{{ translate('Google')}}" name="google" value="{{ $shop->google }}">

                                        </div>

                                    </div>

                                    <div class="row">

                                        <div class="col-md-2">

                                            <label><i class="line-height-1_8 size-24 mr-2 fa fa-youtube bg-youtube c-white text-center"></i>{{ translate('Youtube')}} </label>

                                        </div>

                                        <div class="col-md-10">

                                            <input type="text" class="form-control mb-3" placeholder="{{ translate('Youtube')}}" name="youtube" value="{{ $shop->youtube }}">

                                        </div>

                                    </div>

                                     <div class="row">

                                        <div class="col-md-2">

                                            <label><i class="line-height-1_8 size-24 mr-2 fa fa-youtube bg-youtube c-white text-center"></i>{{ translate('Instagram')}} </label>

                                        </div>

                                        <div class="col-md-10">

                                            <input type="text" class="form-control mb-3" placeholder="{{ translate('Instagram')}}" name="instagram" value="{{ $shop->instagram }}">

                                        </div>

                                    </div>

                                    <div class="row">

                                        <div class="col-md-2">

                                            <label><i class="line-height-1_8 size-24 mr-2 fa fa-youtube bg-youtube c-white text-center"></i>{{ translate('Linkedin')}} </label>

                                        </div>

                                        <div class="col-md-10">

                                            <input type="text" class="form-control mb-3" placeholder="{{ translate('Linkedin')}}" name="linkedin" value="{{ $shop->linkedin }}">

                                        </div>

                                    </div>

                                </div>

                            </div>

                            <div class="text-right mt-4">

                                <button type="submit" class="btn btn-styled btn-base-1">{{ translate('Save')}}</button>

                            </div>

                        </form>

                    </div>

                </div>

            </div>

        </div>

    </section>



@endsection



@section('script')

    <script>

        // Custom file input
        $(".custom-input-file").each(function () {
            var $input = $(this),
                $label = $input.next("label"),
                labelVal = $label.html();

            $input.on("change", function (e) {
                var fileName = "";

                if (this.files && this.files.length > 1)
                    fileName = (
                        this.getAttribute("data-multiple-caption") || ""
                    ).replace("{count}", this.files.length);
                else if (e.target.value)
                    fileName = e.target.value.split("\\").pop();

                if (fileName) $label.find("span").html(fileName);
                else $label.html(labelVal);
            });

            // Firefox bug fix
            $input
                .on("focus", function () {
                    $input.addClass("has-focus");
                })
                .on("blur", function () {
                    $input.removeClass("has-focus");
                });
        });

        var slide_id = 1;

        function add_more_slider_image(){

            var shopSliderAdd =  '<div class="row">';

            shopSliderAdd +=  '<div class="col-2">';

            shopSliderAdd +=  '<button type="button" onclick="delete_this_row(this)" class="btn btn-link btn-icon text-danger"><i class="fa fa-trash-o"></i></button>';

            shopSliderAdd +=  '</div>';

            shopSliderAdd +=  '<div class="col-10">';

            shopSliderAdd +=  '<input type="file" name="sliders[]" id="slide-'+slide_id+'" class="custom-input-file custom-input-file--4" data-multiple-caption="{count} files selected" multiple accept="image/*" />';

            shopSliderAdd +=  '<label for="slide-'+slide_id+'" class="mw-100 mb-3">';

            shopSliderAdd +=  '<span></span>';

            shopSliderAdd +=  '<strong>';

            shopSliderAdd +=  '<i class="fa fa-upload"></i>';

            shopSliderAdd +=  "{{ translate('Choose image')}}";

            shopSliderAdd +=  '</strong>';

            shopSliderAdd +=  '</label>';

            shopSliderAdd +=  '</div>';

            shopSliderAdd +=  '</div>';

            $('#shop-slider-images').append(shopSliderAdd);



            slide_id++;

            imageInputInitialize();

        }

        function delete_this_row(em){

            $(em).closest('.row').remove();

        }





        $(document).ready(function(){

            $('.remove-files').on('click', function(){

                $(this).parents(".col-md-6").remove();

            });

        });

    </script>

@endsection

